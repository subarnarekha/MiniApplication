import { Component, NgModule, enableProdMode,Inject} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule,FormGroup,FormControl, FormBuilder, Validators } from '@angular/forms'
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Person } from './Login'

enableProdMode();

@Component({
  selector: 'my-app',
  templateUrl: 'src/main.html'
})

export class LoginComponent {
  userForm : FormGroup;
  user:Login;
  userName:FormControl;
  password:FormControl;
  
  constructor(@Inject(FormBuilder) private builder:FormBuilder){
    this.builtForm();
  }
  private builtForm(){
    this.userForm = this.builder.group({
		 userName:new FormControl('',
		 Validators.compose([
		   Validators.required,
		   Validators.minLength(4),
		   Validators.maxLength(12),
		   Validators.pattern(/^[a-z]+$/i)
		 ])),
		 password:new FormControl('',
		 Validators.compose([
		   Validators.required,
		   Validators.maxLength(6)
		 ]))
    
    });
  }
   
  onSubmitForm(){
     this.user = this.userForm.value;
     alert("Name : "+this.user.userName+" Pwd:"+this.user.password);
	}
}

@NgModule({
  imports:[ BrowserModule, ReactiveFormsModule ],
  declarations:[ LoginComponent ],
  bootstrap:[ LoginComponent ]
})
class AppModule{}


platformBrowserDynamic().bootstrapModule(AppModule);

  