import { Component } from '@angular/core';

@Component({
    template:`
	
		<!-- TESTIMONIALS -->
		<div class="row row-eq-height">
		<section id="sidebar" class="col-lg-5">
			<div class="panel panel-success">
				<div class="panel-heading">
					<h2 class="panel-title">
					Samsung
					</h2>
				</div>
				<div class="panel-body text-justify">
					<img src="imagesMob/samsung_img.jpg" class="img-responsive" width="400px" height="100px"/>
				</div>
				<div class="panel-footer">
					<a href="#">Read More...</a>
				</div>
			</div>
		</section>
	
		<section id="sidebar" class="col-lg-5 col-lg-offset-1">
			<div class="panel panel-success">
				<div class="panel-heading">
					<h2 class="panel-title">
					Sony
					</h2>
				</div>
				<div class="panel-body text-justify">
				<img src="imagesMob/sony_img.jpg" class="img-responsive" width="400px" height="100px"/>
				</div>
				<div class="panel-footer">
					<a href="#">Read More...</a>
				</div>
			</div>
		</section>
		</div>
		<div class="row row-eq-height">
		<section id="sidebar" class="col-lg-5">
			<div class="panel panel-success">
				<div class="panel-heading">
					<h2 class="panel-title">
					Oppo
					</h2>
				</div>
				<div class="panel-body text-justify">
					<img src="imagesMob/oppo_img.jpg" class="img-responsive" width="400px" height="100px"/>
				</div>
				<div class="panel-footer">
					<a href="#">Read More...</a>
				</div>
			</div>
		</section>
		
		
		<section id="sidebar" class="col-lg-5 col-lg-offset-1">
			<div class="panel panel-success">
				<div class="panel-heading">
					<h2 class="panel-title">
					HTC
					</h2>
				</div>
				<div class="panel-body text-justify">
					<img src="imagesMob/htc_img.jpg" class="img-responsive" width="400px" height="100px"/>
				</div>
				<div class="panel-footer">
					<a href="#">Read More...</a>
				</div>
			</div>
		</section>
		</div>
	`
})


export class HomeComponent {

}
