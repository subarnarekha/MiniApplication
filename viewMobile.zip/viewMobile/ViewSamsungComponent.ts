import { Component,Inject,OnInit,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { SamsungService } from './SamsungService'
import { Samsung } from './Samsung';
import { ActivatedRoute,Router, Params } from '@angular/router';

enableProdMode();

@Component({
  selector: 'my-app',
  templateUrl:'src/viewMobile/SamsView.html'
})
export class ViewSamsungComponent implements OnInit{
   Sams:Samsung[];
   constructor(@Inject(SamsungService) private SamsungService:SamsungService,@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
         
    }
  
  ngOnInit(): void{
    this.Sams = this.SamsungService.getMobilesSam();
  }
  navigateToHome():void{
        this.router.navigate(['/home']);
    }
}