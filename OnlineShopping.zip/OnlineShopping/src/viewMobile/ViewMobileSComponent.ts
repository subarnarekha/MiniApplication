import { Component,Inject,OnInit,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { MobileService } from './MobileService'
import { Mobile } from './Mobile';
import { ActivatedRoute,Router, Params } from '@angular/router';

enableProdMode();

@Component({
  selector: 'my-app',
  templateUrl:'src/viewMobile/newView.html'
})
export class ViewMobileSComponent implements OnInit{
   Mobiles:Mobile[];
   constructor(@Inject(MobileService) private MobileService:MobileService,@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
         
    }
  
  ngOnInit(): void{
    this.Mobiles = this.MobileService.getMobiles();
  }
  navigateToHome():void{
        this.router.navigate(['/home']);
    }
}