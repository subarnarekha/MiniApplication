export interface Samsung{
    id:number,
	name:string,
	author:string
}