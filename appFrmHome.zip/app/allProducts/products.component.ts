import {Component,Inject,OnInit} from "@angular/core";
 import { Product } from './product';
 import { ActivatedRoute, Params } from '@angular/router';
 import {AllProducts} from "./allProducts.service";

 @Component({
    templateUrl:'app/allProducts/allProducts.html'
 //providers:[AppService]
})

export class ProductsComponent implements OnInit{
    
    err:string;
    private products:Product;
    constructor(@Inject(AllProducts) private allProducts:AllProducts){
        
    };

    ngOnInit():void{
		this.allProducts.getProducts().subscribe(response=>this.products=response,error=>this.err=error);
		//this.emp =eServ.getEmployeeById();
	}
    // loginstat:boolean=false;
    // loged:boolean=false;
    //this.appService.getPerson().subscribe(response=>this.persons=response,error=>console.log(error));
    
    // login(){
    //     this.loginstat=true;
    // }

    // loginCredentials(){
    //     var user={
    //         uname:this.username,
    //         pass:this.password
    //     }
    //     console.log(this.username);
    //     this.appService.loginCredentials(user).subscribe(data=>{
    //         console.log("success "+data);
    //         // this.loged=true;
    //         // this.loginstat=false;
    //      },error=>console.log(error));
    // }
}