import { Component,Injectable,Inject,OnInit} from '@angular/core';
import { ViewProductService } from './viewProduct.service';
import { Product } from '../allProducts/product';
import { Customer } from './customer';
import { ActivatedRoute,Router, Params } from '@angular/router';

@Component({
    templateUrl:'app/viewProduct/viewProduct.html'
})
export class ViewComponent{
    private id:number;
    err:string;
    message:string;
    private product:Product;
    quantity:number;
    totalCost:number;
    fname:string;
    mobno:string;
    address:string;
    available:number;
	//private productComp=new ProductsComponent();
        constructor(@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router,
        @Inject(ViewProductService) private viewService:ViewProductService){
           
          this.id = parseInt(this.route.snapshot.params['prodId']);
    }
	ngOnInit(): void{
		//this.emp ={id: 104, name: 'Ravan',desig:'SSE' };
		this.viewService.getProductById(this.id).subscribe(response=>{
            console.log(response.company);
            if(response.company!=null){
                this.product=response;
                console.log(this.product);
            }
            else{
                this.message="Mobile does not found";
            }
            
        },error=>this.err=error);
	}

    buy(){

        this.available=this.product.quantity-this.quantity;
        console.log(this.available);
        this.viewService.buyProduct(this.id,this.available).subscribe(response=>{
            console.log(response.stat);
            console.log(response.sess);
            if(!response.sess){
                this.message="please login to buy a product";
            }
            else if(response.stat){
                this.addPerson();
            }
            else{
                this.message="your booking is cancelled please try again..";
            }
            
        },error=>this.err=error);
    }
    addPerson(){
        var person={
            fname:this.fname,
            mobNo:this.mobno,
            address:this.address,
            company:this.product.company,
            model:this.product.model,
            quantity:this.quantity,
            cost:this.totalCost
        }
        this.viewService.addCustomer(person).subscribe(response=>{
            console.log(response.stat);
            console.log(response.sess);
            if(response.stat){
                this.message="you are successfully booked your mobile";
            }
            else{
                this.message="your booking is cancelled please try again..";
            }
            
        },error=>this.err=error);
    }
}
