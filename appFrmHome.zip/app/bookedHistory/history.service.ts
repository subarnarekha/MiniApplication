import {Injectable, Inject} from "@angular/core";
import{Http,Headers,Response} from "@angular/http";
import { Observable } from 'rxjs/Observable';
import {Customer} from '../viewProduct/customer';
import "rxjs/add/operator/map";

@Injectable()
export class HistoryService{

    //public http:Http
    constructor(@Inject(Http) private http:Http){}

   getHistory():Observable<Customer>{
      return this.http.get('/api/history').map((res:Response)=>{return res.json();});
  }
}
// import {Injectable, Inject} from "@angular/core";
// import {Http,Response} from "@angular/http";
// import {Observable} from 'rxjs/Observable';
// import {Customer} from '../viewProduct/customer';
// import "rxjs/add/operator/map";

// @Injectable()
// export class HistoryService{

//     constructor(@Inject(Http) private http:Http){}

//     getHistory():Observable<Customer>{
//         this.http.get('/api/history').map((res:Response)=>{return res.json();});
//     }
// }