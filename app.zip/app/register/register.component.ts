import { Component, Inject, OnInit } from "@angular/core";
import { RegisterService } from "./register.service";
@Component({
    templateUrl: 'app/register/register.html'
})

export class RegisterComponent implements OnInit {

    uname: string;
    pwd: string;
    cpwd: string;
    status = false;
    err: string;
    message: string;
    show = false;
    stat = false;
    //this.show=false;
    constructor( @Inject(RegisterService) private registerService: RegisterService) { }
    ngOnInit(): void {
        this.show = false;
        this.registerService.check(this.uname).subscribe(response => {
            if (response.sess) {
                this.message = "you are already logged in";
            }
            else {
                this.show = true;
            }
        }, error => this.err = error);
    }
    check() {
        this.registerService.check(this.uname).subscribe(response => {
            // if(response.sess){
            //     this.message="you are already logged in";
            //     this.show=false;
            // }
            if (response.stat) {
                this.message = "username already exist..please try another";
                this.status = true;
                this.stat = true;
            }
            else {
                this.status = false;
                this.stat = false;
            }
        }, error => this.err = error);
    }
    register() {
        var data = {
            uname: this.uname,
            pass: this.pwd
        }
        if (this.pwd && this.cpwd) {
            if (this.pwd === this.cpwd) {

                this.registerService.register(data).subscribe(response => {
                    // if(response.sess){
                    //     this.message="you are already logged in";
                    //     this.show=false;
                    // }
                    if (response) {
                        this.message = "Successfully registered..login now";
                        this.stat = true;
                    }
                    else {
                        this.message = "something went wrong please try again";
                        this.stat = true;
                    }
                }, error => this.err = error);
            }
            else {
                this.message = "two passwords doen not match";
                this.stat = true;
            }
        }
    }
}