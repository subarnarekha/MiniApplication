export interface Customer{
    uname:string;
    fname:string;
    mobNo:string;
    address:string;
    company:string;
    model:string;
    quantity:number;
    cost:number;
}